import './App.css';
import { Route } from 'react-router-dom';
import { BrowserRouter } from 'react-router-dom';
import { Routes } from 'react-router-dom';
import Admin from './admin';
import NotFound from './NotFound';
import Menu from './menu';
import SanPhamList from './SanPhamList';
import SanPhamSua from './SanPhamSua';
import SanPhamThem from './SanPhamThem';
import DangNhap from './DangNhap';
import DangKy from './DangKy';
import { useSelector } from 'react-redux';
import { Navigate } from 'react-router-dom';
import { ProtectedRoute } from './ProtectedRoute';

function App() {
  const user = useSelector(state => state.auth.user);
  const daDangNhap = useSelector(state => state.auth.daDangNhap);
  return (
    <BrowserRouter basename="/">
      <div className="container">
        <header>
          <div id="userinfo">
            {user === null || user === undefined ? "Chào Quý Khách" : "Chào " + user.hoten}
          </div>
        </header>
        <nav> <Menu /> </nav>
        <main>
          <Routes>
            <Route path="/dangnhap" element={<DangNhap />} />
            <Route path="/dangky" element={<DangKy />} />
            <Route path="/download" element={daDangNhap === true ? <download /> : <Navigate to="/dangnhap" />} />
            <Route element={<ProtectedRoute />}>
              <Route path="/" exact element={<Admin />} />
              <Route path="/admin/sp" element={<SanPhamList />} />
              <Route path="/admin/spthem" element={<SanPhamThem />} />
              <Route path="/admin/spsua/:id" element={<SanPhamSua />} />
            </Route>
            <Route path='*' element={<NotFound />} />
          </Routes>
        </main>
        <footer><p>Họ tên sinh viên: Nguyen Ngoc Minh Nhat</p> </footer>
      </div>
    </BrowserRouter>
  );
}
export default App;