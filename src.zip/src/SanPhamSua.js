function SanPhamSua() { return (
    <div id="SanPhamSua"><h1>Đây là trang sua sp</h1> </div>
  )}
export default SanPhamSua;