import React from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

function DangKy() {
  let unRef = React.createRef();
  let pwRef = React.createRef();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const submitDuLieu = () => { // gửi thông tin đăng ký lên server
    if (unRef.current.value === "" || pwRef.current.value === "") {
      alert("Nhập đủ thông tin nhe bạn ơi");
      return;
    }

    let url = "http://localhost:4000/users/signin";
    let tt = { un: unRef.current.value, pw: pwRef.current.value };
    var opt = {
      method: "post",
      body: JSON.stringify(tt),
      headers: { "Content-Type": "application/json" },
    };

    fetch(url, opt)
      .then((res) => res.json())
      .then((data) => {
        if (data.thongbao === "Đăng ký thành công") {
          alert("Đăng ký thành công!");
          navigate("/dangnhap");
        } else {
          alert("Đăng ký thất bại!");
        }
      });
  };

  return (
    <form id="frmdangky" className="col-7 m-auto border border-primary">
      <h2 className="bg-info h5 p-2">Thành viên đăng ký</h2>
      <div className="m-3">
        Tên đăng nhập:
        <input className="form-control" type="text" ref={unRef} />
      </div>
      <div className="m-3">
        Mật khẩu:
        <input className="form-control" type="password" ref={pwRef} />
      </div>
      <div className="m-3">
        <button
          onClick={() => submitDuLieu()}
          className="btn btn-info"
          type="button"
        >
          Đăng ký
        </button>
      </div>
    </form>
  );
}

export default DangKy;
