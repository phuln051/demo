function SanPhamThem() {

  //lưu sản phẩm
  let sp = {};

  const submitDuLieu = () => {

    let url = "http://localhost:4000/adminsp";
    let opt = {
      method: "post",
      body: JSON.stringify(sp),
      headers: {'Content-Type': 'application/json'}
    }

    fetch(url, opt).then(res => res.json()).then(data => {

      console.log("Đã thêm ", data);
      // alert("Đã thêm", data)

      // Xóa dữ liệu đầu vào
      document.querySelector('#frmaddsp').reset();
    });
  }

  return (
    <form id="frmaddsp">
      <h2 className="h4">Thêm sản phẩm</h2>
      <div className="row mb-3">
        <div className='col'>Tên <input type="text" className="form-control" onChange={e => sp.ten_sp = e.target.value} /></div>
        <div className='col'>Loại <select className="form-control" onChange={e => sp.loai = e.target.value}>
        <option value="điện thoại">Điện thoại</option>
        <option value="laptop">Laptop</option>
        <option value="phụ kiện">Phụ kiện</option>
      </select>
    </div>
        <div className='col'> Giá <input type="number" className="form-control" onChange={e => sp.gia = e.target.value} /></div>

     
       <div className='col'> Giá KM <input type="number" className="form-control" onChange={e => sp.gia_km = e.target.value} /></div>
       <div className='col'>RAM <select className="form-control" onChange={e => sp.ram = e.target.value}>
        <option value="4GB">4GB</option>
        <option value="8GB">8GB</option>
        <option value="16GB">16GB</option>
      </select>
    </div>
    <div className='col'>CPU <select className="form-control" onChange={e => sp.cpu = e.target.value}>
        <option value="Intel Core i3">Intel Core i3</option>
        <option value="Intel Core i5">Intel Core i5</option>
        <option value="Intel Core i7">Intel Core i7</option>
      </select>
    </div>
    </div>
      <div className="row mb-3">
        <div className='col'>Hình <input type="text" className="form-control" onChange={e => sp.hinh = e.target.value} /></div>
        <div className='col'>Ngày <input type="date" className="form-control" onChange={e => sp.ngay = e.target.value} /> </div>
        <div className='col'>Lượt xem <input type="number" className="form-control" onChange={e => sp.soluotxem = e.target.value} /></div>
      </div>
      <div className='mb-3'>
        <button className="btn btn-warning" type="button" onClick={() => submitDuLieu()} >Thêm sản phẩm</button> &nbsp;
        <a href="/admin/sp" className='btn btn-info'>Danh sách</a>
      </div>
    </form>
  )
}

export default SanPhamThem;
