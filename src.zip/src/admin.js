function Admin() { return (
      <div id="admin"><h1>Đây là trang chủ quản trị</h1> </div>
    )}
export default Admin;