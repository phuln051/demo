import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function SanPhamList() {
  const [listSP, ganListSP] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [sortOrder, setSortOrder] = useState("asc");
  const [sortColumn, setSortColumn] = useState("ten_sp");

  useEffect(() => {
    fetch("http://localhost:4000/adminsp")
      .then((res) => res.json())
      .then((data) => {
        ganListSP(data);

        const totalItems = data.length;
        const itemsPerPage = 200;
        const totalPages = Math.ceil(totalItems / itemsPerPage);

        setTotalPages(totalPages);
      });
  }, []);

  const navigate = useNavigate();

  const handlePageChange = (newPage) => {
    if (newPage < 1 || newPage > totalPages) return;
    setCurrentPage(newPage);
  };

  const handleSort = (column) => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    setSortColumn(column);
    setCurrentPage(1);
  };

  const xoaSP = (id) => {
    if (window.confirm("Xóa thật không bö?") === false) return false;
    fetch("http://localhost:4000/adminsp/" + id, { method: "delete" })
      .then((res) => res.json())
      .then((data) => navigate(0));
  };

  const handleSortByName = () => {
    handleSort("ten_sp");
  };

  const sortedList = [...listSP].sort((a, b) => {
    const factor = sortOrder === "asc" ? 1 : -1;
    return a[sortColumn].localeCompare(b[sortColumn]) * factor;
  });

  return (
    <div id="adminspList">
      <h5 className="sp" key={0}>
        <b onClick={handleSortByName} className="csshandleSortByName">Tên SP</b> <b>Ngày</b> <b>Giá</b> <b><a href="/admin/spthem">Thêm</a></b>
      </h5>
      {sortedList.slice((currentPage - 1) * 10, currentPage * 10).map((sp, index) => (
        <div className="sp" key={sp.id_sp}>
          <span>{sp.ten_sp}</span> <span>{new Date(sp.ngay).toLocaleDateString("vi")}</span> <span>{new Number(sp.gia).toLocaleString("vi")} VND</span>
          <span>
            <a href="#/" className="btn btn-danger" onClick={() => xoaSP(sp.id_sp)}>Xóa</a> &nbsp;
          </span>
        </div>
      ))}

      <div className="pagination">
        {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
          <a href="#/" key={page} className={`btn btn-primary ${page === currentPage ? "active" : ""}`} onClick={() => handlePageChange(page)}>
            {page}
          </a>
        ))}
      </div>
    </div>
  );
}

export default SanPhamList;
